#### barplotter 1.2         ####
#### Created by: Ed Koleski ####
#### Updated: 2/18/22       ####

##############################################################################################################

# Directory to .xlsx file where the data to be plotted is stored
fname_in = '/Users/edkoleski/Documents/Chang_Lab/scripts/barplotter/barplotter/example/barplotter example data.xlsx' 

# Directory for where to save the file. .pdf format ensures that the output figure can be modified by 
fname_out = '/Users/edkoleski/Documents/Chang_Lab/scripts/barplotter/barplotter/example/out.pdf' 

# Number or name of column to use for grouping the data. 0 indexed.
groupby_col = 'sample name'    
# Number or name of column to plot as the y value. 0 indexed
y_col_name = 5                

# Plot title. No title if blank ex. ('')
title = 'test title'        
# Label for y axis. Can support LaTex formatting if surrounded by '$'. ex. (OD$_{600}$)
y_ax_lab = 'OD$_{600}$'     
# Supply custom names for the bars. ex: {0:'best',4:'worst'}
custom_bar_labels={1:'OK',6:'BAD'}        

# Set y_max value. Set as False if you want to auto determine the y_max
y_max = False

# Color variables can handle some color names (ex. 'red') or Hex values (ex. #FF0000) or RGB decimal values (ex. (255, 0, 0))
# Bar color
bar_color = (255, 0, 0)                    
# Add horizontal grid lines?                                        
horizontal_grid_lines = False            
# Default is 0.35
bar_width = 0.35
# Marker size
ms = 5
# Marker face color.
mfc = 'grey'
# Marker edge width
mew = 1
# Marker edge color
mec = 'black'


##############################################################################################################