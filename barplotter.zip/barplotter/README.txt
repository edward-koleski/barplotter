##### barplotter 1.2 #####

########################################################
#Last updated: 2/18/21
#Created by: Ed Koleski
#Works with Python 3.8.8
########################################################

The purpose of this script is to generate a barplot with positive error bars and data points.
The excel spreadsheet to be imported should have column names in the first row. Example input data and output is included. 

Instructions:
1. Open the file "barplotter_params.py" and adjust the parameters to your preference. 
        - Descriptions are included next to each parameter
        
2. Open your command line (or terminal on MacOS)

Option A:

3A. Enter the following command: python3 (full directory to script)/barplotter.py
    example: /Users/edkoleski/Documents/Chang_Lab/scripts/barplotter/barplotter.py

Option B:

3B. Navigate to the directory where "barplotter.py" and "barplotter_params.py" are stored. (Files must be in the same directory)
        - Option 1: use the cd command to navigate to the directory. ls (mac) or dir (win) to view contents.
        - Option 2: type cd, then drag the directory from finder into the command line. Hit enter.

4B. Enter the following command: python3 barplotter.py



########################################################
Trouble shooting
########################################################
On windows, replacing 'python3' in the commands above with 'python' may help.

Install python 3.8.8:
https://www.python.org/downloads/macos/
Search for "3.8.8"

If you get an error of the type "module xxx not found". (example: "module pandas not found")

pip3 is the preferred installer program for python.
From the command line/terminal, try entering the following commands:

pip3 install --upgrade pip
pip3 install SomePackage

If you run into security issues, try:
pip3 install SomePackage --user

The following are packages that you may need to install. The error should include the missing module's name:
pandas
matplotlib

########################################################
Changes:
########################################################

to do:
- multi bars
- add bottom error bars


Let me know if you run into issues or have suggestions for improvements.

- Ed
edward_koleski@berkeley.edu

