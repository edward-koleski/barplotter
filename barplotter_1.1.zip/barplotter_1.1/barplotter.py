#### barplotter 1.1         ####
#### Created by: Ed Koleski ####
#### Updated: 2/17/22       ####

#####################################################
# Import modules. Set global plot parameters

import numpy as np
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.ticker import AutoMinorLocator, FormatStrFormatter
from sklearn import linear_model
import math
import os
from barplotter_params import *

# adjust the global fontc
font = {'family' : 'sans-serif',
        'sans-serif': 'Arial',
        'weight' : 'regular',
        'size'   : 12}
mpl.rc('font', **font)

# Create a border around the axes
mpl.rc('axes', labelsize=20, labelcolor='0', labelpad= 10, linewidth=1.5, 
       edgecolor='0', xmargin=0.02, ymargin=0.1, titlesize=20)

#####################################################
#Define functions
def color_handler(color):
    if type(color) == tuple:
        color_rgb_list = list(color)
        color_rgb_list = [i/255 for i in color_rgb_list] 
        color = tuple(color_rgb_list)
    return color

def column_index_to_name(plot_data, col_name):
    if type(col_name) == int:
        col_name = plot_data.columns[col_name]
    return col_name

def data_points_locator(input_df, groupby_var, x_ticks, bar_width):
    """Returns a dataframe containing the raw data in addition to the x-cordinates 
    for each replicate sample.
    input_df: df containing ungrouped data. groupby_var: name of column that the data is grouped by
    x_ticks: pd.Series of tick x values and index of labels"""
    
    data_points_df = input_df.copy()
    data_points_df['loc'] = np.nan
    
    for i in data_points_df.index:
        if math.isnan(data_points_df.loc[i,'loc']):
            grp = data_points_df.loc[i, groupby_var]    # get value of groupby_var for group
            rep_idxs = data_points_df.index[data_points_df[groupby_var] == grp] # get idxs for group of reps
            rep_num = len(rep_idxs)                     # how many reps
            x_lab_loc = x_ticks[grp]                     # get location of label
            short_bar_width = 0.7*bar_width              # undershoot the bar width
        
            n = 0
            if rep_num % 2:                              # if rep_num is odd
                start = x_lab_loc - (short_bar_width)/2    # starting x val
                for idx in rep_idxs:
                    data_points_df.loc[idx, 'loc'] = start + n * (short_bar_width) / (rep_num-1)  # set x loc
                    n += 1
            else:
                start = x_lab_loc - (bar_width)/2        # if even
                for idx in rep_idxs:
                    interval = (bar_width) / (rep_num+1) # starting x val
                    data_points_df.loc[idx, 'loc'] = start + (n + 1) * interval
                    n += 1
        else:
            continue    
    return data_points_df


def _1bar(plot_data, groupby_col, title, y_col_name, y_ax_lab, custom_bar_labels, bar_width, 
            fname_out, horizontal_grid_lines, bar_color):

    """ Make a bar graph with one set of bars and data points. Requires data_points_locator function
    
            plot_data: data to plot. Often want to select a subset of the data
            groupby_var: dataframe column name to groupby
            title: title of the plot
            y_col_name: name of dataframe column to plot
            save_dir: Directory to save the figure. format set by out directory.
            custom_tick_labels: Labels for each bar on the x-axis. If False: list(grpd_data.index)
            x_tick_locs: Bar locations. default= np.arange(len(x_tick_labs))
    """
        
    # Get data and group it 
    grpd_data = plot_data.groupby(groupby_col, sort=False).agg([np.mean, np.std])   

    # Set x_tick labels and locations
    bar_labels = list(grpd_data.index)
    bar_locs = np.arange(len(bar_labels))
    x_ticks = pd.Series(bar_locs, index=bar_labels) 
   
    data_points_df = data_points_locator(plot_data, groupby_col, x_ticks, bar_width)
    
    fig, ax = plt.subplots(figsize=(8,6)) # Make fig and axes objects
    
    if horizontal_grid_lines == True:
        ax.grid(color='0.7', axis='y', linestyle='-', linewidth=1.5, zorder=0)  # Add y-axis grid lines
    
    if len(title) != 0: 
        plt.suptitle(title, fontsize = 24, fontweight = 'bold') # Add a title
    
    ax.set_ylabel(y_ax_lab, fontsize=20, fontweight='regular', labelpad=5)
    
    
    for i in custom_bar_labels.keys():
        if i in range(len(bar_labels)):
            bar_labels[i] = custom_bar_labels[i]
        else:
            print(f"Bar label not changed. {i} is not a correct index.")

    ax.set_xticks(bar_locs)
    ax.set_xticklabels(bar_labels, fontsize=20, rotation=0)
    
    #bars
    yerr = [np.zeros(len(grpd_data[y_col_name, 'std'])), grpd_data[y_col_name, 'std'].values]
    
    bars = ax.bar( bar_locs, grpd_data[y_col_name,'mean'], bar_width, 
                   yerr = yerr, color = bar_color, linewidth = 1.5, edgecolor='black', 
                   error_kw = dict(elinewidth = 1.5, capthick = 1.5, ecolor = 'black', capsize = 3),
                   zorder=3) 
    
    data_pts = ax.plot(data_points_df['loc'], data_points_df[y_col_name],
                   'D', mfc='k', ms=5, mew=0, mec='white', zorder=4)

    # Format
    ax.tick_params(axis = 'y', which = 'major', direction='in',   #tick parameters
                    right=False, length = 7, width = 1.5, labelsize=20, pad=10)
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax.tick_params(which='minor', length=4, direction='in', width = 1.5)
    ax.tick_params(axis = 'x', length = 0, pad=10) # remove x ticks
    ax.set_xlim(left=list(x_ticks)[0]-(bar_width/2 + 0.5),
                right = list(x_ticks)[-1]+(bar_width/2 + 0.5))
    if y_max != False:
        ax.set_ylim(top=y_max)
    
    ## Save figure
    fig.savefig(fname_out, bbox_inches = 'tight')
    print(f"\nFigure saved to: {fname_out}\n")
    
    plt.show()
    
#####################################################
#Execute

# Load in data
plot_data = pd.read_excel(fname_in)

# Handle inputs
groupby_col = column_index_to_name(plot_data, groupby_col)
y_col_name = column_index_to_name(plot_data, y_col_name)
bar_color = color_handler(bar_color)

# Plot function
_1bar(plot_data, groupby_col, title, y_col_name, y_ax_lab, custom_bar_labels, bar_width, 
            fname_out, horizontal_grid_lines, bar_color)