#### barplotter 1.1         ####
#### Created by: Ed Koleski ####
#### Updated: 2/17/22       ####

##############################################################################################################

# Directory to .xlsx file where the data to be plotted is stored
fname_in = '/Users/edkoleski/Documents/Chang_Lab/scripts/barplotter/barplotter_1.1/example/barplotter example data.xlsx' 

# Directory for where to save the file. .pdf format ensures that the output figure can be modified by 
fname_out = '/Users/edkoleski/Documents/Chang_Lab/scripts/barplotter/barplotter_1.1/example/out.pdf' 

# Number or name of column to use for grouping the data. 0 indexed.
groupby_col = 'sample name'    
# Number or name of column to plot as the y value. 0 indexed
y_col_name = 5                

# Plot title. No title if blank ex. ('')
title = 'test title'        
# Label for y axis. Can support LaTex formatting if surrounded by '$'. ex. (OD$_{600}$)
y_ax_lab = 'OD$_{600}$'     
# Supply custom names for the bars. ex: {0:'best',4:'worst'}
custom_bar_labels={1:'OK',6:'BAD'}        

# Set y_max value. Set as false if you want to auto determine the y_max
y_max = False

# Can handle some color names (ex. 'red') or Hex values (ex. #FF0000) or RGB decimal values (ex. (255, 0, 0))
bar_color = (255, 0, 0)                    
# Add horizontal grid lines?                                        
horizontal_grid_lines = False            
# Default is 0.35
bar_width = 0.35                         


##############################################################################################################